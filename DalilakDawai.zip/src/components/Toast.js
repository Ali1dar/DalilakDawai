// src/components/Toast.js
import React, { useEffect, useRef } from 'react';
import { Animated, Text, StyleSheet } from 'react-native';

export default function Toast({ message, visible, type = 'info' }) {
  const translateY = useRef(new Animated.Value(-100)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(translateY, { toValue: 0, duration: 400, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      ]).start();
      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(translateY, { toValue: -100, duration: 400, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0, duration: 400, useNativeDriver: true }),
        ]).start();
      }, 2600);
      return () => clearTimeout(timer);
    }
  }, [visible, message]);

  return (
    <Animated.View style={[
      styles.toast,
      { transform: [{ translateY }], opacity },
      type === 'error' ? styles.error : styles.info
    ]}>
      <Text style={styles.text}>{message}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  toast: {
    position: 'absolute', top: 20, left: '10%', right: '10%',
    padding: 14, borderRadius: 30, zIndex: 30000,
    alignItems: 'center', elevation: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.2, shadowRadius: 8,
  },
  info: { backgroundColor: '#00796b' },
  error: { backgroundColor: '#f44336' },
  text: { color: 'white', fontWeight: 'bold', fontSize: 14, textAlign: 'center', fontFamily: 'Cairo-Bold' },
});
