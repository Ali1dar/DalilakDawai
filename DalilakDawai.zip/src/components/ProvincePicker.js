// src/components/ProvincePicker.js
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, Modal, FlatList, StyleSheet, I18nManager
} from 'react-native';
import { PROVINCES } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';

I18nManager.forceRTL(true);

export default function ProvincePicker({ value, onChange, label }) {
  const { theme } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <View style={{ marginBottom: 12 }}>
      {label && <Text style={[styles.label, { color: theme.primary }]}>{label}</Text>}
      <TouchableOpacity
        style={[styles.selector, { backgroundColor: theme.bg, borderColor: theme.border }]}
        onPress={() => setOpen(true)}>
        <Text style={[styles.selectorText, { color: theme.text }]}>{value || 'اختر المحافظة'}</Text>
        <Text style={{ color: theme.subText }}>▼</Text>
      </TouchableOpacity>
      <Modal visible={open} transparent animationType="slide">
        <TouchableOpacity style={styles.overlay} onPress={() => setOpen(false)} activeOpacity={1}>
          <View style={[styles.sheet, { backgroundColor: theme.cardBg }]}>
            <Text style={[styles.sheetTitle, { color: theme.primary }]}>اختر المحافظة</Text>
            <FlatList
              data={PROVINCES}
              keyExtractor={item => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.option, item === value && { backgroundColor: theme.primary + '22' }]}
                  onPress={() => { onChange(item); setOpen(false); }}>
                  <Text style={[styles.optionText, { color: theme.text }, item === value && { color: theme.primary, fontWeight: 'bold' }]}>
                    {item}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 13, fontWeight: 'bold', marginBottom: 5, textAlign: 'right' },
  selector: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 12, borderWidth: 2, borderRadius: 8,
  },
  selectorText: { fontSize: 15 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '70%' },
  sheetTitle: { fontSize: 18, fontWeight: 'bold', textAlign: 'center', marginBottom: 15 },
  option: { paddingVertical: 14, paddingHorizontal: 10, borderRadius: 8, marginBottom: 4 },
  optionText: { fontSize: 15, textAlign: 'right' },
});
