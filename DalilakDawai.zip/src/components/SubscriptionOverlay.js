// src/components/SubscriptionOverlay.js
import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated, Linking, Modal
} from 'react-native';
import { useTheme } from '../utils/ThemeContext';

export default function SubscriptionOverlay({ visible, message }) {
  const { theme } = useTheme();
  const scale = useRef(new Animated.Value(0.9)).current;

  useEffect(() => {
    if (visible) {
      Animated.spring(scale, { toValue: 1, friction: 5, useNativeDriver: true }).start();
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <Animated.View style={[styles.card, { backgroundColor: theme.cardBg, transform: [{ scale }] }]}>
          <View style={styles.iconBox}>
            <Text style={styles.lockIcon}>🔒</Text>
          </View>
          <Text style={styles.title}>تنبيه: صلاحية الحساب متوقفة</Text>
          <Text style={[styles.message, { color: theme.text }]}>{message}</Text>
          <TouchableOpacity
            style={styles.callBtn}
            onPress={() => Linking.openURL('tel:07823017544')}>
            <Text style={styles.callBtnText}>📞 اتصل بالإدارة لتفعيل الحساب</Text>
            <Text style={styles.phoneNumber}>07823017544</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(240,244,248,0.92)',
    alignItems: 'center', justifyContent: 'center', padding: 20,
  },
  card: {
    padding: 35, borderRadius: 24, width: '100%', maxWidth: 420,
    alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 20 }, shadowOpacity: 0.12, shadowRadius: 40,
    elevation: 20,
  },
  iconBox: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(244,67,54,0.1)',
    alignItems: 'center', justifyContent: 'center', marginBottom: 20,
  },
  lockIcon: { fontSize: 36 },
  title: { color: '#e53935', fontSize: 22, fontWeight: 'bold', marginBottom: 12, textAlign: 'center' },
  message: { fontSize: 15, textAlign: 'center', marginBottom: 25, lineHeight: 24, opacity: 0.9 },
  callBtn: {
    backgroundColor: '#00796b', padding: 16, borderRadius: 14,
    alignItems: 'center', width: '100%',
    shadowColor: '#00796b', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 12,
    elevation: 6,
  },
  callBtnText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  phoneNumber: { color: '#b2dfdb', fontSize: 14, marginTop: 4, fontFamily: 'monospace', letterSpacing: 1 },
});
