// src/screens/PharmacyScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, FlatList, Image, Alert,
} from 'react-native';
import { db, firebaseAuth } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';

export default function PharmacyScreen({ onOpenChat, onToast, province, pharmacyName, userId }) {
  const { theme } = useTheme();
  const [requests, setRequests] = useState([]);
  const [empty, setEmpty] = useState(true);
  const [patientNames, setPatientNames] = useState({});
  const [unreadDots, setUnreadDots] = useState({});
  const listenerRef = useRef(null);
  const dotListeners = useRef({});
  const s = makeStyles(theme);

  useEffect(() => {
    if (!province) return;
    if (listenerRef.current) {
      db.ref(`requests/${province}`).off('value', listenerRef.current);
    }

    const q = db.ref(`requests/${province}`).orderByChild('createdAt').limitToLast(100);
    listenerRef.current = q.on('value', snap => {
      let arr = [];
      snap.forEach(child => {
        const d = child.val();
        if (!(d.hiddenBy && d.hiddenBy[userId])) {
          arr.push({ id: child.key, ...d });
        }
      });
      arr.sort((a, b) => b.createdAt - a.createdAt);
      setRequests(arr);
      setEmpty(arr.length === 0);

      // Fetch patient names
      arr.forEach(req => {
        if (req.patientId && !patientNames[req.patientId]) {
          db.ref(`users/${req.patientId}`).once('value').then(s => {
            if (s.exists()) {
              setPatientNames(prev => ({ ...prev, [req.patientId]: s.val().patientName || 'مريض بدون اسم' }));
            }
          });
        }
      });

      // Listen for unread dots
      arr.forEach(req => {
        if (!dotListeners.current[req.id]) {
          const dotRef = db.ref(`chats/${req.id}/${userId}/unreadPharmacy`);
          dotListeners.current[req.id] = dotRef.on('value', snap => {
            setUnreadDots(prev => ({ ...prev, [req.id]: (snap.val() || 0) > 0 }));
          });
        }
      });
    });

    return () => {
      q.off('value', listenerRef.current);
      Object.keys(dotListeners.current).forEach(id => {
        db.ref(`chats/${id}/${userId}/unreadPharmacy`).off('value', dotListeners.current[id]);
      });
      dotListeners.current = {};
    };
  }, [province, userId]);

  const updateStatus = async (id, newStatus, req) => {
    try {
      await db.ref(`requests/${province}/${id}`).update({ status: newStatus });
      onToast('تم التحديث');
    } catch (e) { console.error(e); }
  };

  const hideRequest = (id) => {
    Alert.alert('تأكيد', 'هل تريد إخفاء هذا الطلب من قائمتك؟', [
      { text: 'لا', style: 'cancel' },
      {
        text: 'إخفاء', onPress: async () => {
          await db.ref(`requests/${province}/${id}/hiddenBy`).update({ [userId]: true });
          onToast('تم إخفاء الطلب بنجاح');
        }
      }
    ]);
  };

  const getBadge = (status) => {
    if (status === 'available') return { text: '✅ متوفر', color: '#4caf50', bg: 'rgba(76,175,80,0.15)' };
    if (status === 'rejected') return { text: '❌ غير متوفر', color: '#f44336', bg: 'rgba(244,67,54,0.15)' };
    return { text: '⏳ قيد الانتظار', color: '#ffb300', bg: 'rgba(255,193,7,0.15)' };
  };

  const renderItem = ({ item }) => {
    const badge = getBadge(item.status);
    const distText = isNaN(item.distance) ? item.distance : `يبعد ${item.distance} كم`;
    const pName = patientNames[item.patientId] || 'جاري جلب الاسم...';
    const hasDot = unreadDots[item.id];

    return (
      <View style={[s.requestItem, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
        <View style={s.reqTop}>
          {item.image ? (
            <TouchableOpacity>
              <Image source={{ uri: item.image }} style={[s.prescImg, { borderColor: theme.border }]} />
            </TouchableOpacity>
          ) : null}
          <View style={{ flex: 1 }}>
            <Text style={[s.medName, { color: theme.text }]}>{item.name}</Text>
            <Text style={[s.patientName, { color: theme.primary }]}>👤 المريض: {pName}</Text>
            <View style={s.badgesRow}>
              <View style={[s.badge, { backgroundColor: badge.bg }]}>
                <Text style={[s.badgeText, { color: badge.color }]}>{badge.text}</Text>
              </View>
              <View style={[s.badge, { backgroundColor: 'rgba(0,121,107,0.1)' }]}>
                <Text style={[s.badgeText, { color: theme.primary }]}>📍 {distText}</Text>
              </View>
              <View style={[s.badge, { backgroundColor: 'rgba(0,0,0,0.05)' }]}>
                <Text style={[s.badgeText, { color: theme.text }]}>🏢 {item.province || 'غير محدد'}</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={s.actionRow}>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#4caf50' }]} onPress={() => updateStatus(item.id, 'available', item)}>
            <Text style={s.actionBtnText}>✓ متوفر</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#ff9800' }]} onPress={() => updateStatus(item.id, 'rejected', item)}>
            <Text style={s.actionBtnText}>✕ غير متوفر</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#0288d1' }]} onPress={() => onOpenChat(item.id, item.name)}>
            <Text style={s.actionBtnText}>💬 مراسلة {hasDot ? '🔴' : ''}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#f44336' }]} onPress={() => hideRequest(item.id)}>
            <Text style={s.actionBtnText}>إخفاء</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={[s.container, { backgroundColor: theme.bg }]}>
      <View style={[s.card, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
        <Text style={s.icon}>💊</Text>
        <Text style={[s.cardTitle, { color: theme.primary }]}>
          الطلبات الواردة لـ ({pharmacyName}) - [{province}]
        </Text>
      </View>
      {empty ? (
        <Text style={[s.emptyText, { color: theme.subText }]}>لا توجد طلبات نشطة حالياً في محافظتك.</Text>
      ) : (
        <FlatList
          data={requests}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 15, paddingBottom: 100 }}
        />
      )}
    </View>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: { flex: 1 },
  card: { margin: 15, padding: 20, borderRadius: 15, borderWidth: 1, alignItems: 'center' },
  icon: { fontSize: 40 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginTop: 5 },
  emptyText: { fontStyle: 'italic', textAlign: 'center', marginTop: 20 },
  requestItem: { padding: 15, borderWidth: 1, borderRadius: 12, marginBottom: 10 },
  reqTop: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  prescImg: { width: 50, height: 50, borderRadius: 8, borderWidth: 1 },
  medName: { fontWeight: 'bold', fontSize: 15, textAlign: 'right' },
  patientName: { fontSize: 12, fontWeight: 'bold', textAlign: 'right', marginTop: 2 },
  badgesRow: { flexDirection: 'row', gap: 5, marginTop: 4, flexWrap: 'wrap' },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  badgeText: { fontSize: 11, fontWeight: 'bold' },
  actionRow: { flexDirection: 'row', gap: 6, marginTop: 12, justifyContent: 'flex-end', flexWrap: 'wrap' },
  actionBtn: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 6 },
  actionBtnText: { color: 'white', fontWeight: 'bold', fontSize: 11 },
});
