// src/screens/ChatScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList,
  Image, Animated, Platform, Linking, ScrollView, KeyboardAvoidingView,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import AudioRecorderPlayer from 'react-native-audio-recorder-player';
import Geolocation from 'react-native-geolocation-service';
import { db, firebaseAuth, formatLastSeen } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';

const audioRecorderPlayer = new AudioRecorderPlayer();

export default function ChatScreen({
  visible, onClose, chatId, pharmacyId, role, requestName,
  localRequests, onToast,
}) {
  const { theme } = useTheme();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const [userStatus, setUserStatus] = useState('');
  const [activeTab, setActiveTab] = useState(null);
  const [tabs, setTabs] = useState([]);
  const [tabNames, setTabNames] = useState({});
  const flatListRef = useRef(null);
  const slideAnim = useRef(new Animated.Value(600)).current;
  const msgListenerRef = useRef(null);
  const statusListenerRef = useRef(null);

  const isDirectChat = chatId?.startsWith('p_');
  const activePharmacyId = role === 'pharmacy' ? firebaseAuth.currentUser?.uid : (activeTab || pharmacyId);
  const s = makeStyles(theme);

  useEffect(() => {
    if (visible) {
      Animated.timing(slideAnim, { toValue: 0, duration: 300, useNativeDriver: true }).start();
    } else {
      Animated.timing(slideAnim, { toValue: 700, duration: 300, useNativeDriver: true }).start();
    }
  }, [visible]);

  useEffect(() => {
    if (!visible || !chatId) return;

    if (role === 'patient' && !isDirectChat) {
      loadPharmacyTabs();
    } else {
      const pid = role === 'pharmacy' ? firebaseAuth.currentUser?.uid : pharmacyId;
      startListening(chatId, pid);
    }

    return () => {
      if (msgListenerRef.current) {
        db.ref(`chats/${chatId}/${activePharmacyId}/messages`).off('value', msgListenerRef.current);
      }
      if (statusListenerRef.current) {
        // cleanup
      }
    };
  }, [visible, chatId]);

  const loadPharmacyTabs = async () => {
    const snap = await db.ref(`chats/${chatId}`).once('value');
    if (snap.exists()) {
      const tabIds = [];
      const names = {};
      const promises = [];
      snap.forEach(child => {
        if (child.key !== 'unreadPharmacy' && child.key !== 'unreadPatient') {
          tabIds.push(child.key);
          promises.push(
            db.ref(`users/${child.key}`).once('value').then(s => {
              names[child.key] = s.val()?.pharmacyName || `صيدلية (${child.key.substring(0,5)})`;
            })
          );
        }
      });
      await Promise.all(promises);
      setTabs(tabIds);
      setTabNames(names);
      if (tabIds.length > 0) {
        selectTab(chatId, tabIds[0]);
      }
    }
  };

  const selectTab = (cId, pid) => {
    setActiveTab(pid);
    db.ref(`chats/${cId}/${pid}/unreadPatient`).set(0);
    startListening(cId, pid);
  };

  const startListening = (cId, pid) => {
    if (msgListenerRef.current) {
      db.ref(`chats/${cId}/${pid}/messages`).off('value', msgListenerRef.current);
    }

    // Mark as read
    if (role === 'pharmacy') {
      db.ref(`chats/${cId}/${pid}/unreadPharmacy`).set(0);
    } else {
      db.ref(`chats/${cId}/${pid}/unreadPatient`).set(0);
    }

    msgListenerRef.current = db.ref(`chats/${cId}/${pid}/messages`).on('value', snap => {
      let arr = [];
      if (snap.exists()) {
        snap.forEach(child => arr.push({ id: child.key, ...child.val() }));
      }
      setMessages(arr);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    });

    // Listen to target user status
    let targetUid = pid;
    if (role === 'pharmacy') {
      if (isDirectChat) targetUid = cId.split('_')[1];
      else {
        const req = localRequests?.find(r => r.id === cId);
        if (req) targetUid = req.patientId;
      }
    }

    if (targetUid) {
      db.ref(`users/${targetUid}/presence`).on('value', snap => {
        const data = snap.val();
        if (data?.online === true) setUserStatus('🟢 متصل الآن');
        else setUserStatus(`🕒 ${formatLastSeen(data?.lastSeen)}`);
      });
    }
  };

  const sendMessage = async () => {
    if (!text.trim() || !chatId || !activePharmacyId) return;
    const msg = text.trim();
    setText('');
    const ref = db.ref(`chats/${chatId}/${activePharmacyId}/messages`).push();
    await ref.set({ role, text: msg, timestamp: Date.now() });
    const counterNode = role === 'pharmacy' ? 'unreadPatient' : 'unreadPharmacy';
    const cRef = db.ref(`chats/${chatId}/${activePharmacyId}/${counterNode}`);
    const snap = await cRef.once('value');
    await cRef.set((snap.val() || 0) + 1);
  };

  const sendImage = () => {
    launchImageLibrary({ mediaType: 'photo', quality: 0.6, maxWidth: 600, maxHeight: 600, includeBase64: true }, async res => {
      if (res.assets && res.assets[0] && chatId && activePharmacyId) {
        const base64 = `data:image/jpeg;base64,${res.assets[0].base64}`;
        const ref = db.ref(`chats/${chatId}/${activePharmacyId}/messages`).push();
        await ref.set({ role, image: base64, timestamp: Date.now() });
        onToast('تم إرسال الصورة');
      }
    });
  };

  const toggleRecording = async () => {
    if (!recording) {
      try {
        const result = await audioRecorderPlayer.startRecorder();
        setRecording(true);
        onToast('جاري تسجيل الصوت الآن...');
      } catch {
        onToast('يرجى السماح بصلاحية الميكروفون', 'error');
      }
    } else {
      try {
        const result = await audioRecorderPlayer.stopRecorder();
        setRecording(false);
        const ref = db.ref(`chats/${chatId}/${activePharmacyId}/messages`).push();
        await ref.set({ role, audio: result, timestamp: Date.now() });
        onToast('تم إرسال البصمة الصوتية بنجاح 🎙️');
      } catch { setRecording(false); }
    }
  };

  const sendLocation = () => {
    if (role !== 'pharmacy') return;
    Geolocation.getCurrentPosition(
      async (pos) => {
        const mapUrl = `https://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`;
        const ref = db.ref(`chats/${chatId}/${activePharmacyId}/messages`).push();
        await ref.set({ role: 'pharmacy', locationUrl: mapUrl, timestamp: Date.now() });
        onToast('تم إرسال الموقع بنجاح');
      },
      () => onToast('تعذر تحديد الموقع. يرجى تفعيل الـ GPS.', 'error'),
      { enableHighAccuracy: true }
    );
  };

  const sendQuick = async (qText) => {
    if (qText.includes('سعر هذا العلاج هو: ')) { setText(qText); return; }
    const ref = db.ref(`chats/${chatId}/${activePharmacyId}/messages`).push();
    await ref.set({ role: 'pharmacy', text: qText, timestamp: Date.now() });
    const cRef = db.ref(`chats/${chatId}/${activePharmacyId}/unreadPatient`);
    const snap = await cRef.once('value');
    await cRef.set((snap.val() || 0) + 1);
  };

  const renderMessage = ({ item }) => {
    const isMe = item.role === role;
    return (
      <View style={[s.msgContainer, isMe ? s.msgRight : s.msgLeft]}>
        <View style={[
          s.msgBubble,
          isMe ? { backgroundColor: theme.primary } : { backgroundColor: isDarkPharmacy(item.role, theme) }
        ]}>
          {item.text && <Text style={[s.msgText, { color: isMe ? 'white' : '#333' }]}>{item.text}</Text>}
          {item.image && (
            <Image source={{ uri: item.image }} style={s.msgImage} />
          )}
          {item.audio && (
            <TouchableOpacity
              style={s.audioBtn}
              onPress={() => audioRecorderPlayer.startPlayer(item.audio)}>
              <Text style={{ color: isMe ? 'white' : '#333', fontSize: 14 }}>🎙️ تشغيل الرسالة الصوتية</Text>
            </TouchableOpacity>
          )}
          {item.locationUrl && (
            <TouchableOpacity
              style={s.locationBtn}
              onPress={() => Linking.openURL(item.locationUrl)}>
              <Text style={{ color: '#00796b', fontWeight: 'bold', fontSize: 13 }}>📍 عرض موقع الصيدلية على الخريطة</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  function isDarkPharmacy(msgRole, t) {
    return msgRole === 'patient' ? '#dcf8c6' : (t === 'dark' ? '#005c4b' : '#dcf8c6');
  }

  if (!visible) return null;

  return (
    <Animated.View style={[s.container, { transform: [{ translateY: slideAnim }], backgroundColor: theme.cardBg }]}>
      {/* Header */}
      <View style={s.header}>
        <View style={{ flex: 1 }}>
          <Text style={s.headerTitle}>{requestName || 'المحادثة'}</Text>
          <Text style={s.statusText}>{userStatus}</Text>
        </View>
        <TouchableOpacity onPress={onClose} style={s.closeBtn}>
          <Text style={{ color: 'white', fontSize: 26, fontWeight: 'bold' }}>×</Text>
        </TouchableOpacity>
      </View>

      {/* Pharmacy Tabs (patient side) */}
      {role === 'patient' && tabs.length > 0 && (
        <ScrollView horizontal style={s.tabsBar} showsHorizontalScrollIndicator={false}>
          {tabs.map(tabId => (
            <TouchableOpacity
              key={tabId}
              style={[s.tabBtn, activeTab === tabId && { backgroundColor: theme.primary, borderColor: theme.primary }]}
              onPress={() => selectTab(chatId, tabId)}>
              <Text style={[s.tabBtnText, { color: activeTab === tabId ? 'white' : theme.text }]}>
                {tabNames[tabId] || `صيدلية (${tabId.substring(0,5)})`}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* Messages */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={80}>
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={item => item.id || Math.random().toString()}
          renderItem={renderMessage}
          style={[s.messagesList, { backgroundColor: theme.chatBg }]}
          contentContainerStyle={{ padding: 15, paddingBottom: 20 }}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        />

        {/* Quick Replies (pharmacy only) */}
        {role === 'pharmacy' && (
          <ScrollView horizontal style={s.quickReplies} showsHorizontalScrollIndicator={false}>
            {[
              { label: '🟢 متوفر', text: 'مرحباً، الدواء متوفر لدينا وجاهز للاستلام.' },
              { label: '🔴 غير متوفر', text: 'عذراً، هذا الدواء غير متوفر حالياً.' },
              { label: '📷 صورة أوضح', text: 'يرجى تصوير الوصفة الطبية بشكل أوضح.' },
              { label: '💰 السعر', text: 'أهلاً بك، سعر هذا العلاج هو: ' },
              { label: '📍 موقعي', action: sendLocation },
            ].map((q, i) => (
              <TouchableOpacity
                key={i}
                style={[s.quickBtn, { backgroundColor: theme.cardBg, borderColor: theme.primary }]}
                onPress={() => q.action ? q.action() : sendQuick(q.text)}>
                <Text style={[s.quickBtnText, { color: theme.primary }]}>{q.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {/* Input area */}
        <View style={[s.inputArea, { backgroundColor: theme.cardBg, borderTopColor: theme.border }]}>
          <TouchableOpacity onPress={sendImage} style={s.iconBtn}>
            <Text style={{ fontSize: 22 }}>📷</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={toggleRecording}
            style={[s.iconBtn, recording && { opacity: 0.7 }]}>
            <Text style={{ fontSize: 22 }}>{recording ? '🛑' : '🎙️'}</Text>
          </TouchableOpacity>
          <TextInput
            style={[s.chatInput, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
            placeholder="اكتب رسالتك..."
            placeholderTextColor={theme.subText}
            value={text}
            onChangeText={setText}
            textAlign="right"
            onSubmitEditing={sendMessage}
          />
          <TouchableOpacity style={[s.sendBtn, { backgroundColor: theme.primary }]} onPress={sendMessage}>
            <Text style={s.sendBtnText}>إرسال</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </Animated.View>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 20000,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: '#00796b', padding: 15,
    paddingTop: Platform.OS === 'android' ? 40 : 55,
    flexDirection: 'row', alignItems: 'center',
  },
  headerTitle: { color: 'white', fontWeight: 'bold', fontSize: 17 },
  statusText: { color: '#b2dfdb', fontSize: 11, marginTop: 2 },
  closeBtn: { padding: 5 },
  tabsBar: {
    maxHeight: 55, borderBottomWidth: 1, borderBottomColor: theme.border,
    backgroundColor: theme.bg, paddingHorizontal: 10,
  },
  tabBtn: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1,
    borderColor: theme.border, marginRight: 8, marginVertical: 8,
    backgroundColor: theme.cardBg,
  },
  tabBtnText: { fontWeight: 'bold', fontSize: 12 },
  messagesList: { flex: 1 },
  msgContainer: { marginBottom: 8 },
  msgRight: { alignItems: 'flex-start' },
  msgLeft: { alignItems: 'flex-end' },
  msgBubble: { maxWidth: '75%', padding: 10, borderRadius: 12 },
  msgText: { fontSize: 14, lineHeight: 20 },
  msgImage: { width: 200, height: 150, borderRadius: 8, marginTop: 5 },
  audioBtn: {
    padding: 8, backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 8, marginTop: 5,
  },
  locationBtn: {
    padding: 10, backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 8, marginTop: 5,
  },
  quickReplies: {
    maxHeight: 50, borderTopWidth: 1, borderTopColor: theme.border,
    backgroundColor: theme.bg, paddingHorizontal: 10,
  },
  quickBtn: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 15, borderWidth: 1,
    marginRight: 8, marginVertical: 7,
  },
  quickBtnText: { fontWeight: 'bold', fontSize: 12 },
  inputArea: {
    flexDirection: 'row', padding: 12, gap: 8,
    borderTopWidth: 1, alignItems: 'center',
  },
  iconBtn: { padding: 5 },
  chatInput: {
    flex: 1, padding: 11, borderWidth: 1, borderRadius: 20, fontSize: 14,
  },
  sendBtn: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 20 },
  sendBtnText: { color: 'white', fontWeight: 'bold', fontSize: 14 },
});
