// src/screens/InboxScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, FlatList, Animated, Platform
} from 'react-native';
import { db, firebaseAuth } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';

export default function InboxScreen({ visible, onClose, onOpenChat }) {
  const { theme } = useTheme();
  const [chats, setChats] = useState([]);
  const slideAnim = useRef(new Animated.Value(700)).current;
  const s = makeStyles(theme);
  const listenerRef = useRef(null);

  useEffect(() => {
    Animated.timing(slideAnim, {
      toValue: visible ? 0 : 700, duration: 300, useNativeDriver: true
    }).start();
  }, [visible]);

  useEffect(() => {
    if (!visible) return;
    const uid = firebaseAuth.currentUser?.uid;
    if (!uid) return;

    listenerRef.current = db.ref('chats').on('value', async snap => {
      if (!snap.exists()) { setChats([]); return; }
      let arr = [];
      const promises = [];
      snap.forEach(child => {
        const id = child.key;
        if (id.includes(uid)) {
          const data = child.val()[uid] || {};
          const msgs = data.messages ? Object.values(data.messages) : [];
          let lastMsg = 'اضغط لفتح شاشة المحادثة...';
          if (msgs.length > 0) {
            const last = msgs[msgs.length - 1];
            if (last.text) lastMsg = last.text;
            else if (last.image) lastMsg = '🖼️ [صورة]';
            else if (last.audio) lastMsg = '🎙️ [رسالة صوتية]';
          }
          const unread = data.unreadPharmacy || 0;
          const patientId = id.split('_')[1] || '';

          const entry = { id, lastMsg, unread, patientId, patientName: null };
          arr.push(entry);

          if (patientId) {
            promises.push(
              db.ref(`users/${patientId}`).once('value').then(s => {
                entry.patientName = s.val()?.patientName || 'مريض بدون اسم';
              }).catch(() => {})
            );
          }
        }
      });
      await Promise.all(promises);
      setChats([...arr]);
    });

    return () => {
      if (listenerRef.current) db.ref('chats').off('value', listenerRef.current);
    };
  }, [visible]);

  if (!visible) return null;

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[s.item, { backgroundColor: theme.cardBg, borderColor: item.unread > 0 ? '#e53935' : theme.border },
        item.unread > 0 && s.itemUnread]}
      onPress={() => onOpenChat(item.id)}>
      <View style={{ flex: 1 }}>
        <Text style={[s.name, { color: theme.primary }]}>
          📥 المريض: {item.patientName || 'جاري جلب الاسم...'}
        </Text>
        <Text style={[s.lastMsg, { color: theme.subText }]} numberOfLines={1}>{item.lastMsg}</Text>
      </View>
      {item.unread > 0 && (
        <View style={s.unreadBadge}>
          <Text style={s.unreadText}>{item.unread}</Text>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <Animated.View style={[s.container, { transform: [{ translateY: slideAnim }], backgroundColor: theme.bg }]}>
      <View style={s.header}>
        <Text style={s.headerTitle}>💬 صندوق المحادثات المباشرة</Text>
        <TouchableOpacity onPress={onClose}>
          <Text style={{ color: 'white', fontSize: 26, fontWeight: 'bold' }}>×</Text>
        </TouchableOpacity>
      </View>
      {chats.length === 0 ? (
        <Text style={[s.empty, { color: theme.subText }]}>لا توجد رسائل واردة حالياً.</Text>
      ) : (
        <FlatList
          data={chats}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 15, gap: 10 }}
        />
      )}
    </Animated.View>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 10050,
  },
  header: {
    backgroundColor: '#00796b', padding: 15,
    paddingTop: Platform.OS === 'android' ? 40 : 55,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  headerTitle: { color: 'white', fontWeight: 'bold', fontSize: 18 },
  item: {
    padding: 15, borderRadius: 12, borderWidth: 1,
    flexDirection: 'row', alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.02, elevation: 2,
  },
  itemUnread: { borderRightWidth: 4, borderRightColor: '#e53935' },
  name: { fontWeight: 'bold', fontSize: 15, textAlign: 'right' },
  lastMsg: { fontSize: 13, marginTop: 5, textAlign: 'right' },
  unreadBadge: {
    backgroundColor: '#e53935', borderRadius: 12,
    minWidth: 22, height: 22, alignItems: 'center', justifyContent: 'center', marginLeft: 8,
  },
  unreadText: { color: 'white', fontWeight: 'bold', fontSize: 12 },
  empty: { fontStyle: 'italic', textAlign: 'center', marginTop: 30 },
});
