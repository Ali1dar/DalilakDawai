// src/screens/NearbyScreen.js
import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, FlatList,
  Modal, Linking, ActivityIndicator, Platform
} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import { db, getDistanceFromLatLonInKm } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';

export default function NearbyScreen({ visible, onClose, province, onDirectChat }) {
  const { theme } = useTheme();
  const [pharmacies, setPharmacies] = useState([]);
  const [loading, setLoading] = useState(false);
  const s = makeStyles(theme);

  useEffect(() => {
    if (visible) fetchPharmacies();
  }, [visible]);

  const fetchPharmacies = () => {
    setLoading(true);
    Geolocation.getCurrentPosition(
      pos => load(pos.coords.latitude, pos.coords.longitude),
      () => load(null, null),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const load = async (pLat, pLng) => {
    try {
      const snap = await db.ref('users').orderByChild('province').equalTo(province).once('value');
      let list = [];
      if (snap.exists()) {
        snap.forEach(child => {
          const d = child.val();
          if (d.role === 'pharmacy') {
            let distance = 'غير محدد'; let distValue = Infinity;
            if (pLat && pLng && d.lat && d.lng) {
              distValue = parseFloat(getDistanceFromLatLonInKm(pLat, pLng, d.lat, d.lng));
              distance = `${distValue} كم`;
            }
            list.push({ id: child.key, ...d, distValue, distance });
          }
        });
        list.sort((a, b) => {
          if (a.isNightDuty && !b.isNightDuty) return -1;
          if (!a.isNightDuty && b.isNightDuty) return 1;
          return a.distValue - b.distValue;
        });
      }
      setPharmacies(list);
    } catch { setPharmacies([]); }
    finally { setLoading(false); }
  };

  const renderItem = ({ item }) => (
    <View style={[s.card, { backgroundColor: theme.bg, borderColor: theme.border }]}>
      <View style={s.cardHeader}>
        <Text style={[s.pharmName, { color: theme.primary }]}>{item.pharmacyName || 'صيدلية'}</Text>
        {item.isNightDuty && (
          <View style={s.nightBadge}>
            <Text style={s.nightBadgeText}>🌙 صيدلية خافرة</Text>
          </View>
        )}
      </View>
      <Text style={[s.detail, { color: theme.subText }]}>⏰ <Text style={{ fontWeight: 'bold' }}>أوقات العمل:</Text> {item.workingHours || 'غير محدد'}</Text>
      <Text style={[s.detail, { color: theme.subText }]}>📍 <Text style={{ fontWeight: 'bold' }}>البعد:</Text>
        <Text style={[s.distBadge, { color: '#2196f3' }]}> {item.distance}</Text>
      </Text>
      {item.exclusiveProducts ? (
        <View style={[s.productsBox, { borderColor: theme.accent }]}>
          <Text style={[s.productsText, { color: theme.text }]}>
            <Text style={{ fontWeight: 'bold' }}>⭐ المنتجات الحصرية:</Text>{'\n'}{item.exclusiveProducts}
          </Text>
        </View>
      ) : null}
      <View style={s.btnsRow}>
        {item.lat ? (
          <TouchableOpacity
            style={[s.mapBtn, { backgroundColor: 'rgba(0,121,107,0.1)' }]}
            onPress={() => Linking.openURL(`https://maps.google.com/?q=${item.lat},${item.lng}`)}>
            <Text style={{ color: '#00796b', fontWeight: 'bold', fontSize: 13 }}>🗺️ خريطة</Text>
          </TouchableOpacity>
        ) : null}
        <TouchableOpacity
          style={[s.chatBtn, { backgroundColor: '#0288d1', flex: 1 }]}
          onPress={() => { onClose(); onDirectChat(item.id, item.pharmacyName || 'الصيدلية'); }}>
          <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 13 }}>💬 مراسلة فورية</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={s.overlay}>
        <View style={[s.sheet, { backgroundColor: theme.cardBg }]}>
          <View style={s.sheetHeader}>
            <Text style={[s.sheetTitle, { color: theme.primary }]}>الصيدليات المتاحة</Text>
            <TouchableOpacity onPress={onClose}>
              <Text style={[s.closeBtn, { color: theme.text }]}>×</Text>
            </TouchableOpacity>
          </View>
          {loading ? (
            <ActivityIndicator size="large" color={theme.primary} style={{ marginTop: 30 }} />
          ) : pharmacies.length === 0 ? (
            <Text style={[s.empty, { color: theme.subText }]}>لا توجد صيدليات مسجلة في محافظتك حالياً.</Text>
          ) : (
            <FlatList
              data={pharmacies}
              keyExtractor={item => item.id}
              renderItem={renderItem}
              contentContainerStyle={{ paddingBottom: 20 }}
            />
          )}
        </View>
      </View>
    </Modal>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  sheet: { borderRadius: 15, padding: 20, width: '100%', maxHeight: '75%' },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  sheetTitle: { fontSize: 20, fontWeight: 'bold' },
  closeBtn: { fontSize: 28, fontWeight: 'bold' },
  card: { borderRadius: 12, padding: 15, marginBottom: 10, borderWidth: 1, gap: 6 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  pharmName: { fontWeight: 'bold', fontSize: 16 },
  nightBadge: { backgroundColor: 'rgba(244,67,54,0.1)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  nightBadgeText: { color: '#f44336', fontSize: 11, fontWeight: 'bold' },
  detail: { fontSize: 13, textAlign: 'right', lineHeight: 20 },
  distBadge: { fontSize: 12, fontWeight: 'bold' },
  productsBox: { borderWidth: 1, borderStyle: 'dashed', padding: 8, borderRadius: 6, marginTop: 5 },
  productsText: { fontSize: 12 },
  btnsRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  mapBtn: { padding: 10, borderRadius: 8, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16 },
  chatBtn: { padding: 10, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  empty: { fontStyle: 'italic', textAlign: 'center', marginTop: 20 },
});
