// src/screens/PatientScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList,
  ScrollView, Image, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import Geolocation from 'react-native-geolocation-service';
import { db, firebaseAuth, getDistanceFromLatLonInKm, PHARMACY_LAT, PHARMACY_LON } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';
import ProvincePicker from '../components/ProvincePicker';

export default function PatientScreen({ onOpenChat, onOpenNearby, onToast, province, onProvinceChange }) {
  const { theme } = useTheme();
  const [medInput, setMedInput] = useState('');
  const [uploadedImage, setUploadedImage] = useState(null);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const s = makeStyles(theme);
  const listenerRef = useRef(null);

  useEffect(() => {
    if (!province || !firebaseAuth.currentUser) return;
    const q = db.ref(`requests/${province}`)
      .orderByChild('patientId')
      .equalTo(firebaseAuth.currentUser.uid);
    listenerRef.current = q.on('value', snap => {
      let arr = [];
      snap.forEach(child => arr.push({ id: child.key, ...child.val() }));
      arr.sort((a, b) => b.createdAt - a.createdAt);
      setRequests(arr);
    });
    return () => { if (listenerRef.current) q.off('value', listenerRef.current); };
  }, [province]);

  const pickImage = () => {
    launchImageLibrary({ mediaType: 'photo', quality: 0.7, maxWidth: 800, maxHeight: 800, includeBase64: true }, res => {
      if (res.assets && res.assets[0]) {
        setUploadedImage({ uri: res.assets[0].uri, base64: `data:image/jpeg;base64,${res.assets[0].base64}` });
        onToast('تم إرفاق الصورة بنجاح!');
      }
    });
  };

  const sendRequest = async (medName, distance) => {
    try {
      const newRef = db.ref(`requests/${province}`).push();
      await newRef.set({
        name: medName || 'وصفة طبية (مرفق صورة)',
        image: uploadedImage?.base64 || '',
        distance,
        status: 'pending',
        createdAt: Date.now(),
        patientId: firebaseAuth.currentUser.uid,
        province,
      });
      setMedInput('');
      setUploadedImage(null);
      onToast('تم إرسال الطلب بنجاح!');
    } catch (e) {
      onToast('حدث خطأ أثناء الإرسال', 'error');
    }
  };

  const handleSearch = async () => {
    const medName = medInput.trim();
    if (!medName && !uploadedImage) return onToast('اكتب اسماً أو أرفق صورة!', 'error');
    setLoading(true);
    try {
      Geolocation.getCurrentPosition(
        pos => {
          const dist = getDistanceFromLatLonInKm(pos.coords.latitude, pos.coords.longitude, PHARMACY_LAT, PHARMACY_LON);
          sendRequest(medName, dist.toString());
          setLoading(false);
        },
        () => { sendRequest(medName, 'غير محدد'); setLoading(false); },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } catch {
      sendRequest(medName, 'غير محدد');
      setLoading(false);
    }
  };

  const deleteRequest = (id) => {
    Alert.alert('تأكيد', 'هل أنت متأكد من إلغاء هذا الطلب نهائياً؟', [
      { text: 'لا', style: 'cancel' },
      {
        text: 'نعم، احذفه', style: 'destructive',
        onPress: async () => {
          await db.ref(`requests/${province}/${id}`).remove();
          await db.ref(`chats/${id}`).remove();
          onToast('تم الحذف');
        }
      }
    ]);
  };

  const getBadge = (status) => {
    if (status === 'available') return { text: '✅ متوفر', color: '#4caf50', bg: 'rgba(76,175,80,0.15)' };
    if (status === 'rejected') return { text: '❌ غير متوفر', color: '#f44336', bg: 'rgba(244,67,54,0.15)' };
    return { text: '⏳ قيد الانتظار', color: '#ffb300', bg: 'rgba(255,193,7,0.15)' };
  };

  const renderItem = ({ item }) => {
    const badge = getBadge(item.status);
    return (
      <View style={[s.requestItem, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
        <View style={s.reqTop}>
          {item.image ? (
            <TouchableOpacity>
              <Image source={{ uri: item.image }} style={s.prescImg} />
            </TouchableOpacity>
          ) : null}
          <View style={{ flex: 1 }}>
            <Text style={[s.medName, { color: theme.text }]}>{item.name}</Text>
            <View style={s.badgesRow}>
              <View style={[s.badge, { backgroundColor: badge.bg }]}>
                <Text style={[s.badgeText, { color: badge.color }]}>{badge.text}</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={s.actionRow}>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#0288d1' }]} onPress={() => onOpenChat(item.id, item.name)}>
            <Text style={s.actionBtnText}>💬 المحادثة</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#f44336' }]} onPress={() => deleteRequest(item.id)}>
            <Text style={s.actionBtnText}>🗑 إلغاء الطلب</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={[s.container, { backgroundColor: theme.bg }]} contentContainerStyle={{ paddingBottom: 100 }}>
      <View style={[s.provinceBox, { backgroundColor: theme.bg, borderColor: theme.border }]}>
        <ProvincePicker label="📍 محافظتك الحالية:" value={province} onChange={onProvinceChange} />
      </View>

      <View style={[s.card, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
        <Text style={s.icon}>🔍</Text>
        <Text style={[s.cardTitle, { color: theme.primary }]}>البحث عن الدواء</Text>
        <Text style={[s.cardSubtitle, { color: theme.subText }]}>اكتب اسم العلاج أو قم بإرفاق صورة الوصفة</Text>

        <View style={s.inputRow}>
          <TextInput
            style={[s.textInput, { backgroundColor: theme.cardBg, borderColor: theme.border, color: theme.text }]}
            placeholder="اسم الدواء..."
            placeholderTextColor={theme.subText}
            value={medInput}
            onChangeText={setMedInput}
            textAlign="right"
          />
          <TouchableOpacity style={[s.cameraBtn, { backgroundColor: theme.cardBg, borderColor: theme.border }]} onPress={pickImage}>
            <Text style={{ fontSize: 22 }}>📷</Text>
          </TouchableOpacity>
        </View>

        {uploadedImage && (
          <View style={{ alignItems: 'flex-end', marginBottom: 10 }}>
            <Image source={{ uri: uploadedImage.uri }} style={{ width: 80, height: 80, borderRadius: 8 }} />
            <TouchableOpacity onPress={() => setUploadedImage(null)}>
              <Text style={{ color: '#f44336', fontSize: 12, marginTop: 4 }}>✕ إزالة الصورة</Text>
            </TouchableOpacity>
          </View>
        )}

        <TouchableOpacity
          style={[s.searchBtn, { backgroundColor: theme.primary }, loading && { opacity: 0.7 }]}
          onPress={handleSearch}
          disabled={loading}>
          {loading
            ? <ActivityIndicator color="white" />
            : <Text style={s.searchBtnText}>إرسال الطلب</Text>}
        </TouchableOpacity>

        <TouchableOpacity
          style={[s.nearbyBtn, { backgroundColor: '#607d8b' }]}
          onPress={onOpenNearby}>
          <Text style={s.searchBtnText}>🏥 عرض الصيدليات القريبة والخافرة</Text>
        </TouchableOpacity>
      </View>

      <View style={{ paddingHorizontal: 15 }}>
        <Text style={[s.sectionTitle, { color: theme.primary }]}>طلباتي السابقة:</Text>
        {requests.length === 0 ? (
          <Text style={[s.emptyText, { color: theme.subText }]}>لا توجد طلبات سابقة.</Text>
        ) : (
          <FlatList
            data={requests}
            keyExtractor={item => item.id}
            renderItem={renderItem}
            scrollEnabled={false}
          />
        )}
      </View>
    </ScrollView>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: { flex: 1 },
  provinceBox: { margin: 15, marginBottom: 5, padding: 15, borderRadius: 10, borderWidth: 1 },
  card: {
    margin: 15, padding: 25, borderRadius: 15, borderWidth: 1, alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.05, shadowRadius: 12, elevation: 4,
  },
  icon: { fontSize: 40, marginBottom: 8 },
  cardTitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 5 },
  cardSubtitle: { fontSize: 14, marginBottom: 20, textAlign: 'center' },
  inputRow: { flexDirection: 'row', gap: 10, width: '100%', marginBottom: 14 },
  textInput: {
    flex: 1, padding: 12, borderWidth: 2, borderRadius: 8, fontSize: 16,
  },
  cameraBtn: {
    padding: 12, borderWidth: 2, borderRadius: 8,
    alignItems: 'center', justifyContent: 'center',
  },
  searchBtn: { width: '100%', padding: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  nearbyBtn: { width: '100%', padding: 14, borderRadius: 8, alignItems: 'center' },
  searchBtnText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', textAlign: 'right', marginBottom: 12 },
  emptyText: { fontStyle: 'italic', textAlign: 'center', marginTop: 10 },
  requestItem: {
    padding: 15, borderWidth: 1, borderRadius: 12, marginBottom: 10,
  },
  reqTop: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  prescImg: { width: 50, height: 50, borderRadius: 8, borderWidth: 1, borderColor: theme.border },
  medName: { fontWeight: 'bold', fontSize: 15, textAlign: 'right' },
  badgesRow: { flexDirection: 'row', gap: 6, marginTop: 4, flexWrap: 'wrap' },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  badgeText: { fontSize: 11, fontWeight: 'bold' },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: 12, justifyContent: 'flex-end', flexWrap: 'wrap' },
  actionBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 6 },
  actionBtnText: { color: 'white', fontWeight: 'bold', fontSize: 12 },
});
