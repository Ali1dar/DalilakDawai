// src/screens/SettingsScreen.js
import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView,
  Animated, Switch, Platform, ActivityIndicator
} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import { db, firebaseAuth, PROVINCES } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';
import ProvincePicker from '../components/ProvincePicker';

function SubBadge({ expiry }) {
  const { theme } = useTheme();
  if (expiry === undefined || expiry === null || expiry === '') {
    return (
      <View style={styles.subContainer}>
        <View style={[styles.badge, { backgroundColor: 'rgba(244,67,54,0.15)' }]}>
          <Text style={{ color: '#f44336', fontWeight: 'bold' }}>لا يوجد اشتراك نشط ✕</Text>
        </View>
        <Text style={[styles.subDays, { color: theme.text }]}>يرجى التواصل مع الإدارة للتفعيل</Text>
      </View>
    );
  }
  const n = Number(expiry);
  if (n === -1) return (
    <View style={styles.subContainer}>
      <View style={[styles.badge, { backgroundColor: 'rgba(13,110,253,0.15)' }]}>
        <Text style={{ color: '#0d6efd', fontWeight: 'bold' }}>مفتوح / مدى الحياة Unlimited</Text>
      </View>
      <Text style={[styles.subDays, { color: theme.text }]}>حسابك مفعّل بشكل دائم وغير محدود</Text>
    </View>
  );
  const timeLeft = n - Date.now();
  if (timeLeft <= 0) return (
    <View style={styles.subContainer}>
      <View style={[styles.badge, { backgroundColor: 'rgba(244,67,54,0.15)' }]}>
        <Text style={{ color: '#f44336', fontWeight: 'bold' }}>منتهي الاشتراك ❌</Text>
      </View>
    </View>
  );
  const daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));
  return (
    <View style={styles.subContainer}>
      <View style={[styles.badge, { backgroundColor: 'rgba(76,175,80,0.15)' }]}>
        <Text style={{ color: '#4caf50', fontWeight: 'bold' }}>نشط ومفعّل ✅</Text>
      </View>
      <Text style={[styles.subDays, { color: theme.text }]}>{daysLeft} يوم متبقي للاستخدام</Text>
    </View>
  );
}

export default function SettingsScreen({ visible, onClose, onToast, role, userData }) {
  const { theme } = useTheme();
  const [saving, setSaving] = useState(false);
  const slideAnim = React.useRef(new Animated.Value(700)).current;

  // Patient fields
  const [patientName, setPatientName] = useState('');
  // Pharmacy fields
  const [pharmName, setPharmName] = useState('');
  const [pharmProvince, setPharmProvince] = useState('بغداد');
  const [hours, setHours] = useState('');
  const [isNight, setIsNight] = useState(false);
  const [exclusiveProducts, setExclusiveProducts] = useState('');
  const [locationStatus, setLocationStatus] = useState('لم يتم تحديد الموقع بعد.');
  const [locationOk, setLocationOk] = useState(false);
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);

  const s = makeStyles(theme);

  useEffect(() => {
    Animated[visible ? 'timing' : 'timing'](slideAnim, {
      toValue: visible ? 0 : 700, duration: 300, useNativeDriver: true
    }).start();
  }, [visible]);

  useEffect(() => {
    if (userData) {
      setPatientName(userData.patientName || '');
      setPharmName(userData.pharmacyName || '');
      setPharmProvince(userData.province || 'بغداد');
      setHours(userData.workingHours || '');
      setIsNight(userData.isNightDuty || false);
      setExclusiveProducts(userData.exclusiveProducts || '');
      if (userData.lat && userData.lng) {
        setLat(userData.lat); setLng(userData.lng);
        setLocationOk(true); setLocationStatus('✅ الموقع مسجل مسبقاً.');
      }
    }
  }, [userData]);

  const detectLocation = () => {
    setLocationStatus('جاري التحديد...');
    Geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude); setLng(pos.coords.longitude);
        setLocationOk(true); setLocationStatus('✅ تم التقاط الموقع الجغرافي بنجاح.');
      },
      () => { setLocationStatus('❌ تعذر تحديد الموقع. تأكد من تفعيل الـ GPS.'); setLocationOk(false); },
      { enableHighAccuracy: true }
    );
  };

  const save = async () => {
    setSaving(true);
    try {
      const uid = firebaseAuth.currentUser?.uid;
      if (role === 'patient') {
        if (!patientName.trim()) { onToast('يرجى كتابة الاسم أولاً', 'error'); return; }
        await db.ref(`users/${uid}`).update({ patientName: patientName.trim() });
        onToast('تم تحديث اسمك بنجاح! ✨');
      } else {
        if (!pharmName.trim()) { onToast('يرجى كتابة اسم الصيدلية أولاً', 'error'); return; }
        await db.ref(`users/${uid}`).update({
          pharmacyName: pharmName.trim(), province: pharmProvince,
          workingHours: hours, isNightDuty: isNight, exclusiveProducts,
          lat, lng
        });
        onToast('تم تحديث بيانات الصيدلية بنجاح! ✨');
      }
      onClose();
    } catch (e) { onToast('حدث خطأ أثناء حفظ البيانات', 'error'); }
    finally { setSaving(false); }
  };

  if (!visible) return null;

  return (
    <Animated.View style={[s.container, { transform: [{ translateY: slideAnim }], backgroundColor: theme.cardBg }]}>
      <View style={s.header}>
        <Text style={s.headerTitle}>
          {role === 'patient' ? 'إعدادات حساب المريض' : 'إعدادات حساب الصيدلية'}
        </Text>
        <TouchableOpacity onPress={onClose}>
          <Text style={{ color: 'white', fontSize: 26, fontWeight: 'bold' }}>×</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={s.body} contentContainerStyle={{ paddingBottom: 40 }}>
        {role === 'patient' && (
          <View>
            <Text style={[s.label, { color: theme.primary }]}>تعديل اسم المريض الكامل:</Text>
            <TextInput
              style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
              placeholder="اكتب اسمك الكامل هنا..."
              placeholderTextColor={theme.subText}
              value={patientName}
              onChangeText={setPatientName}
              textAlign="right"
            />
          </View>
        )}

        {role === 'pharmacy' && (
          <View>
            <Text style={[s.label, { color: theme.primary }]}>حالة الاشتراك الحالي:</Text>
            <SubBadge expiry={userData?.subscriptionExpiry} />

            <Text style={[s.label, { color: theme.primary }]}>اسم الصيدلية الرسمي:</Text>
            <TextInput
              style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
              placeholder="مثال: صيدلية الشفاء النموذجية"
              placeholderTextColor={theme.subText}
              value={pharmName}
              onChangeText={setPharmName}
              textAlign="right"
            />

            <Text style={[s.label, { color: theme.primary }]}>تعديل محافظة الصيدلية:</Text>
            <ProvincePicker value={pharmProvince} onChange={setPharmProvince} />

            <View style={s.divider} />
            <Text style={[s.label, { color: theme.primary }]}>📍 الموقع الجغرافي:</Text>
            <TouchableOpacity
              style={[s.locBtn, { backgroundColor: '#0288d1' }]}
              onPress={detectLocation}>
              <Text style={s.locBtnText}>{locationOk ? 'تحديث الموقع الجغرافي' : 'تحديد موقع الصيدلية الحالي (GPS)'}</Text>
            </TouchableOpacity>
            <Text style={[s.locStatus, { color: locationOk ? '#4caf50' : theme.subText }]}>{locationStatus}</Text>

            <Text style={[s.label, { color: theme.primary }]}>⏰ أوقات العمل:</Text>
            <TextInput
              style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
              placeholder="مثال: 8:00 صباحاً - 11:00 مساءً"
              placeholderTextColor={theme.subText}
              value={hours}
              onChangeText={setHours}
              textAlign="right"
            />

            <Text style={[s.label, { color: theme.primary }]}>🌙 نظام الخفارة:</Text>
            <View style={[s.switchRow, { backgroundColor: theme.bg, borderColor: theme.border }]}>
              <Text style={[s.switchLabel, { color: theme.text }]}>هذه الصيدلية خافرة (تعمل 24 ساعة)</Text>
              <Switch value={isNight} onValueChange={setIsNight} trackColor={{ true: theme.primary }} />
            </View>

            <Text style={[s.label, { color: theme.primary, marginTop: 15 }]}>⭐ المنتجات الحصرية/العروض:</Text>
            <TextInput
              style={[s.textarea, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
              placeholder="اكتب المنتجات المتوفرة حصرياً أو العروض الحالية..."
              placeholderTextColor={theme.subText}
              value={exclusiveProducts}
              onChangeText={setExclusiveProducts}
              multiline
              numberOfLines={3}
              textAlign="right"
              textAlignVertical="top"
            />
          </View>
        )}

        <TouchableOpacity
          style={[s.saveBtn, { backgroundColor: theme.primary }, saving && { opacity: 0.7 }]}
          onPress={save}
          disabled={saving}>
          {saving
            ? <ActivityIndicator color="white" />
            : <Text style={s.saveBtnText}>حفظ التغييرات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </Animated.View>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 10000,
  },
  header: {
    backgroundColor: '#00796b', padding: 15,
    paddingTop: Platform.OS === 'android' ? 40 : 55,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  headerTitle: { color: 'white', fontWeight: 'bold', fontSize: 18 },
  body: { flex: 1, padding: 20 },
  label: { fontWeight: 'bold', fontSize: 14, marginBottom: 8, textAlign: 'right' },
  input: {
    padding: 13, borderWidth: 2, borderRadius: 8, fontSize: 15, marginBottom: 15,
  },
  textarea: {
    padding: 13, borderWidth: 2, borderRadius: 8, fontSize: 14, marginBottom: 15, minHeight: 80,
  },
  divider: { height: 1, backgroundColor: theme.border, marginVertical: 15 },
  locBtn: { padding: 13, borderRadius: 8, alignItems: 'center', marginBottom: 8 },
  locBtnText: { color: 'white', fontWeight: 'bold' },
  locStatus: { fontSize: 12, textAlign: 'right', marginBottom: 15 },
  switchRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 12, borderRadius: 8, borderWidth: 1, marginBottom: 5,
  },
  switchLabel: { fontWeight: 'bold', fontSize: 14, flex: 1, textAlign: 'right', marginLeft: 10 },
  saveBtn: { padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 15 },
  saveBtnText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  subContainer: { alignItems: 'center', padding: 15, marginBottom: 15 },
  badge: { paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20, marginBottom: 5 },
  subDays: { fontSize: 15, fontWeight: 'bold' },
});

const styles = StyleSheet.create({
  subContainer: { alignItems: 'center', padding: 12, gap: 6 },
  badge: { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 15 },
  subDays: { fontSize: 14, fontWeight: 'bold' },
});
