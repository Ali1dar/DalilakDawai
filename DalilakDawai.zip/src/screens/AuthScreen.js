// src/screens/AuthScreen.js
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { firebaseAuth, db, PROVINCES, getArabicErrorMessage } from '../utils/firebase';
import { useTheme } from '../utils/ThemeContext';
import ProvincePicker from '../components/ProvincePicker';

export default function AuthScreen({ onToast }) {
  const { theme, isDark, toggleTheme } = useTheme();
  const [isLogin, setIsLogin] = useState(true);
  const [method, setMethod] = useState('email'); // 'email' | 'phone'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [province, setProvince] = useState('بغداد');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const confirmationRef = useRef(null);

  const s = makeStyles(theme);

  const handleEmailAuth = async () => {
    if (!email || !password) return onToast('يرجى إدخال البريد وكلمة المرور', 'error');
    setLoading(true);
    try {
      if (isLogin) {
        await firebaseAuth.signInWithEmailAndPassword(email.trim(), password.trim());
      } else {
        if (!fullName.trim()) {
          setLoading(false);
          return onToast('يرجى كتابة الاسم الكامل للمريض', 'error');
        }
        const cred = await firebaseAuth.createUserWithEmailAndPassword(email.trim(), password.trim());
        const defaultExpiry = Date.now() + 30 * 24 * 60 * 60 * 1000;
        await db.ref(`users/${cred.user.uid}`).set({
          role: 'patient',
          patientName: fullName.trim(),
          email: email.trim(),
          province,
          subscriptionExpiry: defaultExpiry,
        });
      }
    } catch (err) {
      onToast(getArabicErrorMessage(err.code), 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async () => {
    let phoneNum = phone.trim();
    if (!phoneNum) return onToast('يرجى إدخال رقم الهاتف كاملاً ومبتدئاً بمفتاح الدولة (+)', 'error');
    if (!phoneNum.startsWith('+')) phoneNum = '+' + phoneNum;
    setLoading(true);
    try {
      const confirmation = await firebaseAuth.signInWithPhoneNumber(phoneNum);
      confirmationRef.current = confirmation;
      setOtpSent(true);
      onToast('تم إرسال رمز التفعيل بنجاح 💬');
    } catch (err) {
      onToast(getArabicErrorMessage(err.code), 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmOtp = async () => {
    if (!otp.trim()) return onToast('يرجى إدخال رمز التحقق المكون من 6 أرقام', 'error');
    setLoading(true);
    try {
      const result = await confirmationRef.current.confirm(otp.trim());
      const user = result.user;
      const snap = await db.ref(`users/${user.uid}`).once('value');
      if (!snap.exists()) {
        const defaultExpiry = Date.now() + 30 * 24 * 60 * 60 * 1000;
        await db.ref(`users/${user.uid}`).set({
          role: 'patient',
          patientName: 'مريض هاتف جديد',
          phone: user.phoneNumber,
          province,
          subscriptionExpiry: defaultExpiry,
        });
      }
      onToast('تم تسجيل الدخول بنجاح!');
    } catch (err) {
      onToast('الرمز غير صحيح أو انتهت صلاحيته.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[s.container, { backgroundColor: theme.bg }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">

        {/* Header */}
        <LinearGradient colors={['#00796b', '#004d40']} style={s.header}>
          <Text style={s.headerTitle}>دليلك الدوائي</Text>
          <TouchableOpacity onPress={toggleTheme} style={s.themeBtn}>
            <Text style={s.themeBtnText}>{isDark ? '☀️' : '🌙'}</Text>
          </TouchableOpacity>
        </LinearGradient>

        <View style={[s.card, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
          <Text style={s.icon}>🔐</Text>
          <Text style={[s.title, { color: theme.primary }]}>
            {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
          </Text>
          <Text style={[s.subtitle, { color: theme.subText }]}>
            {isLogin ? 'مرحباً بك، يرجى تسجيل الدخول للمتابعة' : 'قم بإنشاء حسابك الجديد'}
          </Text>

          {/* Method Tabs */}
          <View style={s.tabs}>
            <TouchableOpacity
              style={[s.tab, method === 'email' && { backgroundColor: theme.primary }]}
              onPress={() => setMethod('email')}>
              <Text style={[s.tabText, { color: method === 'email' ? 'white' : theme.text }]}>البريد الإلكتروني</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[s.tab, method === 'phone' && { backgroundColor: theme.primary }]}
              onPress={() => setMethod('phone')}>
              <Text style={[s.tabText, { color: method === 'phone' ? 'white' : theme.text }]}>رقم الهاتف</Text>
            </TouchableOpacity>
          </View>

          {/* Province Picker */}
          <ProvincePicker label="اختر المحافظة:" value={province} onChange={setProvince} />

          {/* Email Fields */}
          {method === 'email' && (
            <View>
              {!isLogin && (
                <TextInput
                  style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
                  placeholder="الاسم الكامل للمريض"
                  placeholderTextColor={theme.subText}
                  value={fullName}
                  onChangeText={setFullName}
                  textAlign="right"
                />
              )}
              <TextInput
                style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
                placeholder="البريد الإلكتروني"
                placeholderTextColor={theme.subText}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                textAlign="right"
              />
              <TextInput
                style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
                placeholder="كلمة المرور"
                placeholderTextColor={theme.subText}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                textAlign="right"
              />
            </View>
          )}

          {/* Phone Fields */}
          {method === 'phone' && (
            <View>
              {!otpSent ? (
                <TextInput
                  style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
                  placeholder="مثال: 9647700000000+"
                  placeholderTextColor={theme.subText}
                  value={phone}
                  onChangeText={setPhone}
                  keyboardType="phone-pad"
                  textAlign="right"
                />
              ) : (
                <TextInput
                  style={[s.input, { backgroundColor: theme.bg, borderColor: theme.border, color: theme.text }]}
                  placeholder="أدخل رمز التحقق (6 أرقام)"
                  placeholderTextColor={theme.subText}
                  value={otp}
                  onChangeText={setOtp}
                  keyboardType="numeric"
                  maxLength={6}
                  textAlign="right"
                />
              )}
            </View>
          )}

          {/* Action Button */}
          <TouchableOpacity
            style={[s.btn, { backgroundColor: theme.primary }]}
            onPress={() => {
              if (method === 'email') handleEmailAuth();
              else if (!otpSent) handleSendOtp();
              else handleConfirmOtp();
            }}
            disabled={loading}>
            {loading
              ? <ActivityIndicator color="white" />
              : <Text style={s.btnText}>
                  {method === 'email'
                    ? (isLogin ? 'دخول' : 'إنشاء حساب')
                    : (!otpSent ? 'إرسال رمز التفعيل' : 'تأكيد الرمز والدخول')}
                </Text>}
          </TouchableOpacity>

          {/* Toggle Login/Register */}
          <TouchableOpacity onPress={() => setIsLogin(!isLogin)} style={{ marginTop: 8 }}>
            <Text style={[s.toggle, { color: theme.primary }]}>
              {isLogin ? 'ليس لديك حساب؟ إنشاء حساب جديد' : 'لديك حساب بالفعل؟ تسجيل الدخول'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const makeStyles = (theme) => StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 20, paddingTop: Platform.OS === 'android' ? 45 : 55,
  },
  headerTitle: { color: 'white', fontSize: 20, fontWeight: 'bold' },
  themeBtn: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  themeBtnText: { color: 'white', fontWeight: 'bold', fontSize: 13 },
  card: {
    margin: 15, padding: 25, borderRadius: 15, borderWidth: 1,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.05, shadowRadius: 12, elevation: 4,
  },
  icon: { fontSize: 40, textAlign: 'center', marginBottom: 10 },
  title: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 5 },
  subtitle: { fontSize: 14, textAlign: 'center', marginBottom: 20 },
  tabs: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  tab: {
    flex: 1, padding: 10, borderRadius: 8, borderWidth: 1,
    borderColor: theme.border, alignItems: 'center', backgroundColor: theme.bg,
  },
  tabText: { fontWeight: 'bold', fontSize: 14 },
  input: {
    padding: 13, borderWidth: 2, borderRadius: 8, fontSize: 15,
    marginBottom: 14, writingDirection: 'rtl',
  },
  btn: {
    padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 5, marginBottom: 10,
  },
  btnText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  toggle: { textAlign: 'center', textDecorationLine: 'underline', fontSize: 14 },
});
