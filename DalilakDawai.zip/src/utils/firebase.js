// src/utils/firebase.js
import database from '@react-native-firebase/database';
import auth from '@react-native-firebase/auth';

// Firebase config is handled via google-services.json (Android) & GoogleService-Info.plist (iOS)
// Place google-services.json in android/app/
// The config values from the original app:
// apiKey: "AIzaSyDtVddk_FoOXoD7_xObpuC_HCjRg94wct4"
// authDomain: "viralboost-web-38eec.firebaseapp.com"
// databaseURL: "https://viralboost-web-38eec-default-rtdb.firebaseio.com"
// projectId: "viralboost-web-38eec"
// storageBucket: "viralboost-web-38eec.firebasestorage.app"
// messagingSenderId: "195415969543"
// appId: "1:195415969543:android:fe2ec226a1afb2f9577fa2"

export const db = database();
export const firebaseAuth = auth();

export const PROVINCES = [
  'بغداد', 'أربيل', 'الأنبار', 'بابل', 'البصرة', 'حلبجة',
  'دهوك', 'القادسية', 'ديالى', 'ذي قار', 'السليمانية',
  'صلاح الدين', 'كركوك', 'كربلاء', 'المثنى', 'ميسان',
  'النجف', 'نينوى', 'واسط'
];

export const PHARMACY_LAT = 32.6160;
export const PHARMACY_LON = 44.0249;

export function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
}

function deg2rad(deg) {
  return deg * (Math.PI / 180);
}

export function formatLastSeen(timestamp) {
  if (!timestamp) return 'غير نشط';
  if (timestamp === 'online') return 'متصل الآن';
  const diff = Date.now() - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (seconds < 60) return 'نشط منذ ثوانٍ';
  if (minutes < 60) return `نشط منذ ${minutes} د`;
  if (hours < 24) return `نشط منذ ${hours} ساعة`;
  return `نشط منذ ${days} يوم`;
}

export function getArabicErrorMessage(errorCode) {
  switch (errorCode) {
    case 'auth/invalid-email':
      return 'عذراً، البريد الإلكتروني الذي كتبته غير صحيح (مثال: name@email.com).';
    case 'auth/user-not-found':
      return 'لم نجد حساباً مسجلاً بهذا البريد، يرجى التأكد منه أو إنشاء حساب جديد.';
    case 'auth/wrong-password':
      return 'كلمة المرور غير صحيحة، يرجى إعادة المحاولة.';
    case 'auth/email-already-in-use':
      return 'هذا البريد الإلكتروني مسجل لدينا بالفعل، يمكنك تسجيل الدخول به مباشرة.';
    case 'auth/weak-password':
      return 'كلمة المرور ضعيفة جداً، يرجى كتابة 6 أرقام أو حروف على الأقل.';
    case 'auth/network-request-failed':
      return 'فشل الاتصال بالسيرفر، يرجى التحقق من جودة اتصالك بالإنترنت.';
    case 'auth/too-many-requests':
      return 'تم حظر العمليات مؤقتاً لكثرة المحاولات الخاطئة، يرجى الانتظار قليلاً.';
    case 'auth/invalid-credential':
      return 'بيانات الدخول غير صحيحة، يرجى التأكد من البريد الإلكتروني وكلمة المرور.';
    case 'auth/user-disabled':
      return 'تم إيقاف هذا الحساب من قبل الإدارة، يرجى التواصل معنا لمزيد من التفاصيل.';
    default:
      return 'حدث خطأ غير متوقع أثناء المعالجة، يرجى إعادة المحاولة لاحقاً.';
  }
}
