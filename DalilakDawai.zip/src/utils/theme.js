// src/utils/theme.js
export const lightTheme = {
  bg: '#f0f4f8',
  cardBg: '#ffffff',
  text: '#333333',
  subText: '#666666',
  primary: '#00796b',
  border: '#e0e0e0',
  accent: '#ff9800',
  chatBg: '#e5ddd5',
  headerGradient: ['#00796b', '#004d40'],
};

export const darkTheme = {
  bg: '#121212',
  cardBg: '#1e1e1e',
  text: '#e0e0e0',
  subText: '#a0a0a0',
  primary: '#14b8a6',
  border: '#333333',
  accent: '#ff9800',
  chatBg: '#111b21',
  headerGradient: ['#00796b', '#004d40'],
};
